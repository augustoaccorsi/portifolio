const Constants = {
    PAGES: {
        HOME: 'HOME',
        ABOUT: 'ABOUT',
        TECH_STACK: 'TECH_STACK',
        PROJECTS: 'PROJECTS',
        CONTACT: 'CONTACT',
    }
}

export default Constants;